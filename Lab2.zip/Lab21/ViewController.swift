//
//  ViewController.swift
//  Lab21
//
//  Created by Chinedu Agwu on 10/11/18.
//  Copyright © 2018 Chinedu Agwu. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController, UITextFieldDelegate, UICollectionViewDataSource, UICollectionViewDelegate,CLLocationManagerDelegate{

    //@IBOutlet weak var namesWebView: UIWebView!
    @IBOutlet var nameTextField: UITextField!
    @IBOutlet var collectionNames: UICollectionView!
    var timer:Timer! = nil
    var namesArray = [String]()
    var emojiarray = [String]()
    var count: Int = 0
   // var namesArray:[String] = ["1","2"]
    var locationManager:CLLocationManager!
    var CorrectUserLocation = CLLocation()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        nameTextField.delegate = self
        nameTextField.backgroundColor = UIColor.yellow
        collectionNames.dataSource = self
        locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization()
        
        if CLLocationManager.locationServicesEnabled(){
            locationManager.startUpdatingLocation()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return namesArray.count
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        var totalDistance : Double = 0
        let latitude: CLLocationDegrees = 37.7
        let longitude: CLLocationDegrees = -122.03
        
        let classLocation: CLLocation = CLLocation(latitude: latitude,longitude: longitude)
        let userCurrentLocation = locations.last!
        
        if (count<5) {
            count += 1
            return
        }
        if(count == 5){ // Initialize previous location on first call
             CorrectUserLocation = userCurrentLocation
            locationManager.stopMonitoringSignificantLocationChanges()
            locationManager.stopUpdatingLocation()
       totalDistance += CorrectUserLocation.distance(from: classLocation)
            print("found at ",CorrectUserLocation)
            print("total %.2f",totalDistance/100)
            let checks:Double = totalDistance/100
            securityCheck(totalDistance: checks)
        }
       /* distanceLabel.text = NSString(format: "%.2f", totalDistance/1000) as String + " km"
        count += 1*/
    }
    
    func securityCheck(totalDistance: Double){
        //check distance of user from classroom
        if(totalDistance>100.0){
        nameTextField.isUserInteractionEnabled = false
            let alert = UIAlertController(title: "Alert", message: "You are not in class", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else{
        nameTextField.isUserInteractionEnabled = true
        }
    }
  
    
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error \(error)")
    }
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let collectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionCell_Id", for: indexPath)
            as! MyCollectionViewCell // Type down-casting
        if let nameLabel = collectionViewCell.nameLabel { //unwrap nameLabel due to type downcasting 
            if (namesArray.count > indexPath.row) {
            nameLabel.text = namesArray[indexPath.row] }
        if let emojilabel = collectionViewCell.emojiLabel { //unwrap nameLabel due to type downcasting
                if (namesArray.count > indexPath.row) {
                emojilabel.text = emojiarray[indexPath.row] }
            }
    }
    return collectionViewCell }
    //Called just before the textField becomes active
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool { print("textFieldShouldBeginEditing")
        // textField becomes yellow when entering in edition 
        
        return true
    }
    func textFieldDidBeginEditing(_ textField: UITextField) { print("textFieldDidBeginEditing")
        nameTextField.backgroundColor = UIColor.yellow
    }
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool { print("textFieldShouldEndEditing")
        // textField backs to white when ending edition 
        textField.backgroundColor = UIColor.yellow
        return true
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        print("textFieldDidEndEditing")
    nameTextField.backgroundColor = UIColor.yellow    }
    

    func textFieldShouldReturn(_ textField: UITextField) -> Bool { // resign textField's focus
        textField.resignFirstResponder()
        // call submitToService(name:) only if textField.text is not nil
        if let text = textField.text {
            submitToService(name:text) }
        return true
    }

    func submitToService(name:String) { // we use a default argument label
        do {
        let stringUrl = "http://stephane.ayache.perso.luminy.univ-amu.fr/cgi-bin/serviceJson2.py"
        let encodedStringUrl = stringUrl.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
        let myurl = URL(string: encodedStringUrl!) //unwrapp
        if (name != "") {
            // empty uitextfield,
            nameTextField.text = ""
            // might want to unable it to prevent multi registration (even if web service takes care of duplicates) nameTextField.isEnabled = false // true ?
            nameTextField.placeholder = "You already put your name"
            nameTextField.backgroundColor = UIColor.yellow
        }
        
            
            // download json content
            let jsonString = try String(contentsOf: myurl!)
            let jsonData = jsonString.data(using: .utf8)
            let jsonJSON = try JSONSerialization.jsonObject(with: jsonData!, options: [])
            if let dictionary = jsonJSON as? [String: Any] {
                // access individual value in dictionary
                if let retrieved = dictionary["names"] as? [Any],  let retrievedEmoji = dictionary["emojis"] as? [Any]{ // get users
                    namesArray = retrieved as! [String]
                    emojiarray = retrievedEmoji as! [String]
                    // replace escaped characters
                    for (i, name) in namesArray.enumerated() { namesArray[i] = name.removingPercentEncoding!
                    }
                   
                }
                
            }

        } catch {
            print("Error getting url content") }

        //let request = URLRequest(url:myurl!)
        //namesWebView.loadRequest(request)
        collectionNames.reloadData()
        
            }
    func refresh(){
    submitToService(name: "")
    }
/*
    func randomEmoji() -> String {
        let range = 0x1F300...0x1F3F0
        let index = Int(arc4random_uniform(UInt32(range.count)))
        let ord = range.lowerBound + index
        guard let scalar = UnicodeScalar(ord) else { return "❓" }
        return String(scalar)
    }
     
     func decode(_ s: String) -> String? {
     let data = s.data(using: .utf8)!
     return String(data: data, encoding: .nonLossyASCII)
     }
     */
    
    

}

 
