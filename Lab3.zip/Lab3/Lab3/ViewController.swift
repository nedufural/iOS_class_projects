//
//  ViewController.swift
//  Lab3
//
//  Created by Chinedu Agwu on 10/16/18.
//  Copyright © 2018 Chinedu Agwu. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController,UITextFieldDelegate, CLLocationManagerDelegate, MKMapViewDelegate {
    @IBOutlet var addressTextField: UITextField!
    @IBOutlet var myMapView: MKMapView!
    @IBOutlet var distances: UILabel!
    @IBOutlet var zoomSlider: UISlider!
    @IBOutlet var geoFeatureSwitch: UISwitch!

    
    var count:Int = 0
    var startDate: Date!
    var totalDistance: Double = 0
    var previousLocation: CLLocation!
    var currentLocation: CLLocation!
    let geocoder = CLGeocoder()
    let locationManager = CLLocationManager()
    var lastLocation:CLLocation = CLLocation()
    var locationSet = Bool()


    @IBAction func SlideControl(_ sender: UISlider) {
        setMapViewLocationAndDistance(coordinate: myMapView.centerCoordinate)
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let lineRenderer = MKPolylineRenderer(overlay: overlay)
        lineRenderer.strokeColor = UIColor.green
        lineRenderer.lineWidth = 5
        return lineRenderer
        
    }
    @IBAction func geoFeatureSwitch(_ sender: UISwitch) {
        if(geoFeatureSwitch.isOn) {
            locationManager.startUpdatingLocation()
            locationManager.startUpdatingHeading()
            //            addressTextField.isHidden = true
            UIView.animate(withDuration: 0.5, animations: {
                self.addressTextField.alpha = 0
            }, completion: { _ in
                print("addressTextField is now hidden")
            })
            
        }else{
            locationManager.stopUpdatingLocation()
            locationManager.stopUpdatingHeading()
            //            addressTextField.isHidden = false
            UIView.animate(withDuration: 0.5, animations: {
                self.addressTextField.alpha = 0.5
            }, completion: { _ in
                print("addressTextField is now shown")
            })
        }
    }
    func fowardGeocodding(WithAddress address:String) {
        geocoder.geocodeAddressString(address) {
            let placemarks = $0.0
            // shorthand's first member
            if let placemark = placemarks?.first {
                let coordinateRegion = MKCoordinateRegionMakeWithDistance((placemark.location?.coordinate)!, 1000, 1000)
                self.myMapView.setRegion(coordinateRegion, animated: true) }
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool { // resign textField's focus
        textField.resignFirstResponder()
        if let text = textField.text {
            fowardGeocodding(WithAddress: text)
        }
        return true
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        locationManager.delegate = self
        let status = CLLocationManager.authorizationStatus()
        if (status == .notDetermined) {
            locationManager.requestWhenInUseAuthorization()
        } else if (status == .authorizedWhenInUse) {
            locationManager.startUpdatingLocation()
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.distanceFilter = 10
            myMapView.showsUserLocation = true
            myMapView.userTrackingMode = .follow
        } else {
            print("Not allowed to access current location")
        
        
        
        }
        addressTextField.backgroundColor = UIColor.darkGray
        addressTextField.placeholder = "enter address here"
        addressTextField.textColor = UIColor.white
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    /*/override var prefersStatusBarHidden: Bool {
        return true
    }*/
    override var shouldAutorotate: Bool {
        return false
    }

    
    func setMapViewLocationAndDistance(coordinate: CLLocationCoordinate2D){
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(coordinate,  Double(zoomSlider.value), Double(zoomSlider.value))
        self.myMapView.setRegion(coordinateRegion, animated: true)
    }
    
    override func motionEnded(_ motion: UIEventSubtype, with event: UIEvent?) {
        if motion == .motionShake && !geoFeatureSwitch.isOn {
            // make new string instance from existing string
            //            let previousText = String(describing:distanceLabel.text!)
            distances.text = "Reset tracking..."
            distances.textColor = UIColor.red
            totalDistance = 0
            let overlays = myMapView.overlays
            myMapView.removeOverlays(overlays)
            Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { _ in
                //                self.distanceLabel.text = previousText
                self.distances.text = NSString(format: "%.2f", self.totalDistance/1000) as String + " km"
                self.distances.textColor = UIColor.black
            }
        }
    }

    
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
    
        if (status == .authorizedWhenInUse) {
            locationManager.startUpdatingLocation()
        } else {
            print("Not allowed to access current location")
        }
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        
        let currentLocation = locations.last!
        
        setMapViewLocationAndDistance(coordinate: currentLocation.coordinate)
        
        //        let coordinateRegion = MKCoordinateRegionMakeWithDistance(currentLocation.coordinate, 1000, 1000)
        //        self.myMapView.setRegion(coordinateRegion, animated: true)
        
        print("count: " + String(count))
        print("horizontal accuracy: " + String(currentLocation.horizontalAccuracy))
        print("vertical accuracy: " + String(currentLocation.verticalAccuracy))
        print("current location: " + String(currentLocation.coordinate.latitude) + "-" +  String(currentLocation.coordinate.longitude))
        print("distance: " + String(totalDistance))
        
        if (count<5) {
            count += 1
            return
        }
        if(count == 5){ // Initialize previous location on first call
            previousLocation = currentLocation
        }
        totalDistance += currentLocation.distance(from: previousLocation)
        previousLocation = currentLocation
        distances.text = NSString(format: "%.2f", totalDistance/1000) as String + " km"
        count += 1
        
        
        // Draw on map
        let line: MKPolyline = MKPolyline(coordinates: [currentLocation.coordinate, previousLocation.coordinate], count: 2)
        myMapView.add(line)    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        if (error as? CLError)?.code == .denied {
            manager.stopUpdatingLocation()
            manager.stopMonitoringSignificantLocationChanges()
        }
    }
    
    
}


    




