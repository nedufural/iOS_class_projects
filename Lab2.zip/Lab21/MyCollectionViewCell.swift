//
//  MyCollectionViewCell.swift
//  Lab21
//
//  Created by Chinedu Agwu on 10/16/18.
//  Copyright © 2018 Chinedu Agwu. All rights reserved.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var emojiLabel: UILabel!
    @IBOutlet var titleImages :UIImageView!
}
