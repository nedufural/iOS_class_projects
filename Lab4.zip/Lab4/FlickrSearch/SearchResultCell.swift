//
//  SearchResultCell.swift
//  FlirckSearch
//
//  Created by Chinedu Agwu on 10/16/18.
//  Copyright © 2018 Chinedu Agwu. All rights reserved.
//


import UIKit

class SearchResultCell: UITableViewCell {
    
    @IBOutlet weak var resultTitleLabel: UILabel!
    @IBOutlet weak var resultImageView: UIImageView!
    
    
    func setupWithPhoto(flickrPhoto: FlickrPhoto) {
        resultTitleLabel.text = flickrPhoto.title
        resultImageView.sd_setImage(with: flickrPhoto.photoUrl as URL!)
    }
    
}
