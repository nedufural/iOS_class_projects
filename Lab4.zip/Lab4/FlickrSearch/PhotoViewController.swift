//
//  PhotoViewController.swift
//  FlirckSearch
//
//  Created by Chinedu Agwu on 10/16/18.
//  Copyright © 2018 Chinedu Agwu. All rights reserved.
//

import Foundation

class PhotoViewController: UIViewController, UIScrollViewDelegate {
    
    @IBOutlet weak var photoImageView: UIImageView!
    @IBOutlet weak var Scrollview: UIScrollView!
    
    var flickrPhoto: FlickrPhoto?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if flickrPhoto != nil {
            photoImageView.sd_setImage(with: flickrPhoto!.photoUrl as URL!)
        }
        Scrollview.minimumZoomScale = 1.0
        Scrollview.maximumZoomScale = 6.0
    }
    
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        
        return photoImageView
    }
    
}
