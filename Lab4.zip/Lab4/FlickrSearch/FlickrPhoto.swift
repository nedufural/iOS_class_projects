//
//  SearchResult.swift
//  FlirckSearch
//
//  Created by Chinedu Agwu on 10/16/18.
//  Copyright © 2018 Chinedu Agwu. All rights reserved.
//
import UIKit

struct FlickrPhoto {
    
    let photoId: String
    let farm: Int
    let secret: String
    let server: String
    let title: String
    
    var photoUrl: NSURL {
        return NSURL(string: "https://farm\(farm).staticflickr.com/\(server)/\(photoId)_\(secret)_m.jpg")!
    }
    
}
