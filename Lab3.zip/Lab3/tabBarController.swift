//
//  tabBarController.swift
//  Lab3
//
//  Created by Chinedu Agwu on 10/24/18.
//  Copyright © 2018 Chinedu Agwu. All rights reserved.
//

import UIKit
class tabBarController: UITabBarController{

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        viewControllers = []
    }
}
